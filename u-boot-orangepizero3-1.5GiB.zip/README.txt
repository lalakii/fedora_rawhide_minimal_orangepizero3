msdos + ext4

使用extlinux.conf指定FDT